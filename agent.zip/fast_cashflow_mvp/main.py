import asyncio
import sys
from src.utils.logger import logger
from src.utils.report import write_report
from src.sources.reddit_source import RedditSource
from src.ai.ollama_client import OllamaBrain
from src.validation.scorer import Scorer
from src.validation.deduplicator import Deduplicator
from src.storage.sqlite_repo import SqliteRepo
from src.alerting.telegram import send_alert
from config import cfg

async def run_cycle():
    logger.info("Starting cycle...")
    
    # Init modules
    reddit = RedditSource()
    brain = OllamaBrain()
    scorer = Scorer()
    db = SqliteRepo()
    dedup = Deduplicator(db)

    # 1. Fetch
    raw_opps = await reddit.get_opportunities()
    logger.info(f"Fetched {len(raw_opps)} raw items")
    report_items = []

    for opp in raw_opps:
        title_guess = opp['raw_text'].split('\n')[0].strip()
        # 2. Fast Filter (Dedup + Keyword)
        if not dedup.is_new(title_guess):
            logger.info(f"Skipping duplicate: {opp['id']}")
            report_items.append({
                "status": "trash",
                "reason": "duplicate",
                "title": title_guess,
                "url": opp["url"],
                "source": opp["source"],
                "total_score": 0
            })
            continue

        base_score = scorer.hard_filter(opp['raw_text'])
        if base_score < 1:
            logger.info(f"Low base score: {opp['id']}")
            report_items.append({
                "status": "trash",
                "reason": "no_keywords",
                "title": title_guess,
                "url": opp["url"],
                "source": opp["source"],
                "total_score": base_score
            })
            continue

        # 3. AI Analysis (Heavy lifting)
        logger.info(f"Analyzing with AI: {opp['id']}")
        ai_result = await brain.extract_and_score(opp['raw_text'])
        
        if not ai_result.get('is_job'):
            report_items.append({
                "status": "trash",
                "reason": ai_result.get("error", "ai_rejected"),
                "title": ai_result.get("title", title_guess),
                "summary": ai_result.get("summary", ""),
                "price_str": ai_result.get("price_str", "N/A"),
                "tech_stack": ai_result.get("tech_stack", []),
                "url": opp["url"],
                "source": opp["source"],
                "total_score": base_score
            })
            continue

        total_score = base_score + ai_result.get('ai_score', 0)
        
        # 4. Action
        if total_score >= cfg.MIN_SCORE_TO_ALERT:
            logger.success(f"HIGH VALUE FOUND: {total_score}")
            alert_data = {
                "title": ai_result.get('title', 'Unknown'),
                "url": opp['url'],
                "total_score": total_score,
                "price_str": ai_result.get('price_str'),
                "tech_stack": ai_result.get('tech_stack')
            }
            await send_alert(alert_data)
            db.add(opp['id'], alert_data['title'], opp['url'], total_score)
            report_items.append({
                "status": "alert",
                "reason": "score_pass",
                "title": alert_data["title"],
                "summary": ai_result.get("summary", ""),
                "price_str": alert_data.get("price_str", "N/A"),
                "tech_stack": alert_data.get("tech_stack", []),
                "url": opp["url"],
                "source": opp["source"],
                "total_score": total_score
            })
        else:
             logger.info(f"Score too low ({total_score}): {opp['id']}")
             report_items.append({
                 "status": "trash",
                 "reason": "score_below_threshold",
                 "title": ai_result.get("title", title_guess),
                 "summary": ai_result.get("summary", ""),
                 "price_str": ai_result.get("price_str", "N/A"),
                 "tech_stack": ai_result.get("tech_stack", []),
                 "url": opp["url"],
                 "source": opp["source"],
                 "total_score": total_score
             })

    write_report(
        "report.html",
        report_items,
        {"sources": reddit.get_urls()}
    )

async def main():
    loop_mode = "--loop" in sys.argv
    while True:
        try:
            await run_cycle()
        except Exception as e:
            logger.error(f"Cycle failed: {e}")
        
        if not loop_mode:
            break
        
        logger.info("Sleeping 5 minutes...")
        await asyncio.sleep(300)

if __name__ == "__main__":
    asyncio.run(main())
