import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
    TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
    OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "mistral")
    KEYWORDS = [
        kw.strip().lower()
        for kw in os.getenv("TARGET_KEYWORDS", "python,script").split(",")
        if kw.strip()
    ]
    DB_PATH = "opportunities.db"
    
    # Thresholds
    MIN_SCORE_TO_ALERT = 3
    SIMILARITY_THRESHOLD = 85.0

cfg = Config()
