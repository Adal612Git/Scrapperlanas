from config import cfg

class Scorer:
    def hard_filter(self, text: str) -> int:
        """Fast regex-based scoring before AI"""
        score = 0
        text = text.lower()
        
        # Keyword matching
        for kw in cfg.KEYWORDS:
            if kw in text:
                score += 1
        
        # Reddit usually tags hiring posts
        if "[hiring]" in text or "hiring" in text:
            score += 2
        
        return score
