import json
import urllib.parse
from config import cfg
from src.ingestion.http_client import ResilientClient

class RedditSource:
    def __init__(self):
        self.client = ResilientClient()
        # Using .json extension is a hack to get structured data easily from Reddit without API key
        # fallback to HTML scraping if this fails in V2
        self.urls = [
            "https://www.reddit.com/r/forhire/new/.json?limit=25",
            "https://www.reddit.com/r/freelance_forhire/new/.json?limit=15",
        ]

        self.search_urls = []
        for kw in cfg.KEYWORDS[:6]:
            q = urllib.parse.quote(f"subreddit:forhire {kw}")
            self.search_urls.append(f"https://www.reddit.com/search.json?q={q}&sort=new&limit=5")

    def get_urls(self):
        return self.urls + self.search_urls

    async def get_opportunities(self):
        opps = []
        for url in self.get_urls():
            data = await self.client.fetch(url)
            if not data: continue
            
            try:
                # Try parsing as JSON first (Reddit trick)
                json_data = json.loads(data)
                posts = json_data['data']['children']
                for post in posts:
                    p = post['data']
                    title = p.get('title', '')
                    selftext = p.get('selftext', '')
                    opps.append({
                        "source": "reddit",
                        "id": p.get('id', ''),
                        "url": f"https://reddit.com{p.get('permalink', '')}",
                        "raw_text": f"{title}\n{selftext}",
                        "posted_at": p.get('created_utc', 0)
                    })
            except:
                pass # HTML fallback logic would go here
        return opps
