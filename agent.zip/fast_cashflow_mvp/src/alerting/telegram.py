import aiohttp
from config import cfg
from loguru import logger


async def send_alert(data: dict):
    if not cfg.TELEGRAM_TOKEN:
        logger.warning("No Telegram Token configured")
        return
    if not cfg.TELEGRAM_CHAT_ID:
        logger.warning("No Telegram Chat ID configured")
        return

    msg = (
        "FAST CASHFLOW ALERT\n"
        f"Score: {data['total_score']}/5\n\n"
        f"Title: {data['title']}\n"
        f"Price: {data.get('price_str', 'N/A')}\n"
        f"Stack: {', '.join(data.get('tech_stack', []))}\n\n"
        f"URL: {data['url']}"
    )

    url = f"https://api.telegram.org/bot{cfg.TELEGRAM_TOKEN}/sendMessage"
    async with aiohttp.ClientSession() as session:
        await session.post(url, json={
            "chat_id": cfg.TELEGRAM_CHAT_ID,
            "text": msg
        })
