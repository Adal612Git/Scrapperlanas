# Instrucciones para Victor

Victor: eres un super agente de alta elite. Este documento te prepara para arrancar desde cero.

## Que es el sistema Hunter
Hunter es el sistema para que puedas juntar trabajo y hacer dinero mientras Loto continua con su funcionamiento. Su objetivo es detectar oportunidades, ordenarlas por valor y avisarte rapido para que puedas actuar.

## Como usar Hunter (operacion diaria)
1. Asegura las variables de entorno (.env) y dependencias instaladas.
2. Ejecuta el ciclo principal para recolectar oportunidades.
3. Revisa alertas y decide accion (contacto, presupuesto, propuesta).
4. Mantiene registro local en SQLite para evitar duplicados y medir resultados.

## Alta desde cero (sin pruebas previas, por ZIP)
1. Descomprime el ZIP en una carpeta nueva.
2. Entra a la carpeta del proyecto.
3. Crea y activa un entorno virtual de Python.
4. Instala dependencias desde requirements.txt.
5. Crea el archivo .env tomando .env.example como base.
6. Verifica que Ollama este instalado y corriendo en localhost:11434.
7. Ejecuta el sistema con el comando principal (ver main.py).

## Convenciones clave
- No uses APIs pagas.
- Prioriza velocidad, resiliencia y bajo costo.
- Si falla el scraping, reintenta con backoff.
- Si el parsing es debil, usa el modulo de AI local.

## Recordatorio operativo
Tu trabajo es mantener Hunter vivo y rentable. Asegura continuidad, ajusta filtros y responde rapido a oportunidades de valor.
